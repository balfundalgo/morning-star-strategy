# config.py
# ─────────────────────────────────────────────────────────────
# All configurable parameters for Morning Star / Evening Star
# NIFTY Options strategy on Dhan
# ─────────────────────────────────────────────────────────────

import os
from dotenv import load_dotenv

load_dotenv()

# ── Dhan Credentials ──────────────────────────────────────────
DHAN_CLIENT_ID    = os.getenv("DHAN_CLIENT_ID", "").strip()
DHAN_ACCESS_TOKEN = os.getenv("DHAN_ACCESS_TOKEN", "").strip()

# ── Mode ──────────────────────────────────────────────────────
PAPER_TRADE = True          # True = log signals only, no real orders

# ── Instrument ────────────────────────────────────────────────
NIFTY_INDEX_SECURITY_ID = "13"          # IDX_I security_id for NIFTY 50
NIFTY_INDEX_EXCHANGE    = "IDX_I"
OPTIONS_EXCHANGE        = "NSE_FNO"     # Exchange segment for NIFTY options
OPTIONS_INSTRUMENT      = "OPTIDX"      # Instrument type in Dhan scrip master
OPTIONS_UNDERLYING      = "NIFTY"       # Symbol root

# ── Target Delta for strike selection ─────────────────────────
TARGET_DELTA            = 0.60          # Near-delta-0.6 strike
# Since Dhan doesn't provide live delta, we approximate by
# moneyness rank from ATM: the ~4th strike OTM ≈ delta 0.6 ITM
# Actual implementation uses IV-based approximation (see strike_selector.py)

# ── Session Times (IST 24h) ───────────────────────────────────
SESSION_START_TIME      = "09:29"       # No trades before this
LAST_ENTRY_TIME         = "14:45"       # No new entries after this
CANCEL_PENDING_TIME     = "15:10"       # Cancel all pending orders
FORCE_EXIT_TIME         = "15:15"       # Close all open positions

# ── Candle Classification Thresholds ─────────────────────────
# body_ratio = abs(close - open) / (high - low)
LARGE_BODY_RATIO        = 0.60          # C1 & C3: body must be >= 60% of range
SMALL_BODY_RATIO        = 0.35          # C2: body must be <= 35% of range
MIN_CANDLE_RANGE        = 0.5           # Ignore candles with range < 0.5 pts (noise)

# ── Entry Rules ───────────────────────────────────────────────
ENTRY_BUFFER_OPTIONS    = 1.0           # Points above C3 high (BUY) / below C3 low (SELL)
ENTRY_CANDLE_WINDOW     = 2             # Pattern valid for next N candles only

# ── Stop Loss Rules ───────────────────────────────────────────
# BUY:  SL = lowest low of 3-candle pattern
# SELL: SL = highest high of 3-candle pattern
# Index-equivalent max SL cap (not used for options directly,
# but used to filter very wide patterns)
MAX_SL_INDEX_POINTS     = 30

# ── Target Rules ──────────────────────────────────────────────
RISK_REWARD_RATIO       = 1.5           # TP = entry ± (1.5 × risk)

# ── Position & Trade Limits ───────────────────────────────────
MAX_TRADES_PER_DAY      = 5
LOT_SIZE                = 75            # NIFTY options lot size (1 lot)
QUANTITY                = LOT_SIZE * 1  # Trade 1 lot

# ── WebSocket ─────────────────────────────────────────────────
WS_URL = (
    f"wss://api-feed.dhan.co?version=2"
    f"&token={DHAN_ACCESS_TOKEN}"
    f"&clientId={DHAN_CLIENT_ID}"
    f"&authType=2"
)

INSTRUMENT_CSV_URL = "https://images.dhan.co/api-data/api-scrip-master-detailed.csv"

# ── Logging ───────────────────────────────────────────────────
LOG_FILE = "strategy.log"
