# main.py
# ─────────────────────────────────────────────────────────────
# Morning Star / Evening Star Strategy — Main Orchestrator
# Built on Dhan WebSocket feed (adapted from dhan_ws_1m_dashboard.py)
#
# Instruments subscribed:
#   - NIFTY 50 Index (IDX_I) → price feed for candle building
#   - Selected NIFTY Option   → WebSocket premium feed (for live SL/TP monitoring)
#
# Flow:
#   1. WS tick → CandleEngine builds 1m candles
#   2. On candle close → PatternDetector scans last 3 candles
#   3. Pattern found → StrikeSelector finds Delta-0.6 option
#   4. Pending signal armed → waits for price breach (2-candle window)
#   5. Breach detected via tick → OrderManager places entry
#   6. TradeTracker monitors SL/TP/time-exit via option premium ticks
# ─────────────────────────────────────────────────────────────

import os
import sys
import json
import time
import signal
import struct
import logging
import threading
from collections import deque
from datetime import datetime
from typing import Dict, Optional, Any, List

import requests
import pytz
import websocket
from dotenv import load_dotenv

# ── Local modules ─────────────────────────────────────────────
from config import (
    DHAN_CLIENT_ID, DHAN_ACCESS_TOKEN, WS_URL,
    NIFTY_INDEX_SECURITY_ID, NIFTY_INDEX_EXCHANGE,
    ENTRY_BUFFER_OPTIONS, LOG_FILE, PAPER_TRADE,
    INSTRUMENT_CSV_URL,
)
from session_guard import SessionGuard
from pattern_detector import scan_for_pattern, PatternResult
from strike_selector import StrikeSelector
from order_manager import OrderManager
from trade_tracker import TradeTracker, PendingSignal, ActiveTrade

load_dotenv()

# ── Logging setup ─────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("main")

IST = pytz.timezone("Asia/Kolkata")

# ── Dhan WS constants (reused from dashboard) ─────────────────
REQ_SUB_TICKER  = 15
RESP_TICKER     = 2
RESP_PREV_CLOSE = 6
RESP_DISCONNECT = 50

EXCH_SEG_MAP_NUM_TO_NAME = {
    0: "IDX_I", 1: "NSE_EQ", 2: "NSE_FNO",
    3: "NSE_CURRENCY", 4: "BSE_EQ", 5: "MCX_COMM",
    7: "BSE_CURRENCY", 8: "BSE_FNO",
}

# ANSI
GREEN = "\033[92m"; RED = "\033[91m"; YELLOW = "\033[93m"
BOLD = "\033[1m"; DIM = "\033[2m"; RESET = "\033[0m"


# ─────────────────────────────────────────────────────────────
# Time helpers (copied from dashboard to keep standalone)
# ─────────────────────────────────────────────────────────────

def _normalize_dhan_epoch(ts: int) -> int:
    ts = int(ts)
    now_ts = int(time.time())
    diff = ts - now_ts
    if int(4.5 * 3600) <= diff <= int(6.5 * 3600):
        ts -= 19800
    return ts

def minute_bucket_epoch(epoch_sec: int) -> int:
    epoch_sec = _normalize_dhan_epoch(int(epoch_sec))
    return epoch_sec - (epoch_sec % 60)


# ─────────────────────────────────────────────────────────────
# CandleEngine (from dashboard, extended with on_close callback)
# ─────────────────────────────────────────────────────────────

class CandleEngine:
    def __init__(self, sec_id: str, name: str, history_len: int = 50):
        self.sec_id = str(sec_id)
        self.name   = name
        self.lock   = threading.Lock()

        self.last_ltp: Optional[float]  = None
        self.last_ltt_epoch: Optional[int] = None

        self.current: Optional[Dict[str, Any]] = None
        self.completed: deque = deque(maxlen=history_len)

        # Callback: called with completed candle dict when a candle closes
        self.on_candle_close_cb = None

    def on_tick(self, ltp: float, ltt_epoch: int):
        ltp        = float(ltp)
        ltt_epoch  = _normalize_dhan_epoch(int(ltt_epoch))
        bucket     = minute_bucket_epoch(ltt_epoch)

        with self.lock:
            self.last_ltp        = ltp
            self.last_ltt_epoch  = ltt_epoch

            if self.current is None:
                self.current = self._new_candle(bucket, ltp)
                return

            cur_bucket = int(self.current["bucket"])

            if bucket == cur_bucket:
                self.current["high"]  = max(float(self.current["high"]), ltp)
                self.current["low"]   = min(float(self.current["low"]),  ltp)
                self.current["close"] = ltp
                self.current["tick_count"] += 1
                return

            if bucket > cur_bucket:
                closed = dict(self.current)
                self.completed.append(closed)
                self.current = self._new_candle(bucket, ltp)

                # Fire callback outside lock to avoid deadlock
                cb = self.on_candle_close_cb
                if cb:
                    threading.Thread(
                        target=cb,
                        args=(self.sec_id, closed),
                        daemon=True,
                    ).start()

    @staticmethod
    def _new_candle(bucket: int, price: float) -> Dict[str, Any]:
        return {
            "bucket": bucket, "open": price, "high": price,
            "low": price, "close": price, "tick_count": 1,
        }

    def get_completed_candles(self) -> List[Dict[str, Any]]:
        with self.lock:
            return list(self.completed)

    def get_ltp(self) -> Optional[float]:
        with self.lock:
            return self.last_ltp


# ─────────────────────────────────────────────────────────────
# Binary parsers (identical to dashboard)
# ─────────────────────────────────────────────────────────────

def parse_header_8(msg: bytes) -> Optional[Dict[str, Any]]:
    if len(msg) < 8:
        return None
    resp_code    = msg[0]
    exch_seg_num = msg[3]
    sec_id_i     = struct.unpack_from("<I", msg, 4)[0]
    return {
        "resp_code":    resp_code,
        "exch_seg_name": EXCH_SEG_MAP_NUM_TO_NAME.get(exch_seg_num, str(exch_seg_num)),
        "security_id":  str(sec_id_i),
        "payload":      msg[8:],
    }

def parse_ticker(payload: bytes) -> Optional[Dict[str, Any]]:
    if len(payload) < 8:
        return None
    return {
        "ltp":       float(struct.unpack_from("<f", payload, 0)[0]),
        "ltt_epoch": int(struct.unpack_from("<I", payload, 4)[0]),
    }

def parse_prev_close(payload: bytes) -> Optional[Dict[str, Any]]:
    if len(payload) < 4:
        return None
    return {"prev_close": float(struct.unpack_from("<f", payload, 0)[0])}


# ─────────────────────────────────────────────────────────────
# StrategyEngine — the brain
# ─────────────────────────────────────────────────────────────

class StrategyEngine:
    """
    Wires together PatternDetector, StrikeSelector,
    OrderManager, TradeTracker, and SessionGuard.
    """

    def __init__(self):
        self.session   = SessionGuard()
        self.strikes   = StrikeSelector()
        self.orders    = OrderManager()
        self.tracker   = TradeTracker()
        self._lock     = threading.Lock()

        # Spot price (updated from NIFTY index ticks)
        self._nifty_spot: Optional[float] = None

        mode = f"{GREEN}PAPER TRADE{RESET}" if PAPER_TRADE else f"{RED}LIVE TRADE{RESET}"
        logger.info(f"StrategyEngine started | Mode: {mode}")

    # ── Called by App when NIFTY tick arrives ─────────────────

    def on_nifty_tick(self, ltp: float):
        with self._lock:
            self._nifty_spot = ltp

        # If there's an active trade, check SL/TP breach on each tick
        # (In paper trade, we monitor spot as proxy since option feed may not be subscribed)
        self._check_sl_tp_on_tick(ltp)

        # If there's a pending signal, check entry trigger breach
        self._check_entry_trigger_on_tick(ltp)

    # ── Called by CandleEngine when a 1m candle closes ────────

    def on_nifty_candle_close(self, sec_id: str, candle: Dict[str, Any]):
        """
        Main strategy logic — runs after every completed 1m candle.
        """
        now_str = datetime.now(IST).strftime("%H:%M:%S")

        # ── Time gate ─────────────────────────────────────────
        session_status = self.session.status_str()

        # Force exit at 15:15
        if self.session.is_force_exit_time():
            if self.tracker.has_active_trade():
                logger.info("15:15 FORCE EXIT triggered")
                self._force_exit("TIME_EXIT")
            return

        # Cancel pending orders at 15:10
        if self.session.is_cancel_pending_time():
            pending = self.tracker.get_pending_signal()
            if pending:
                logger.info("15:10 — Cancelling pending entry signal")
                self.tracker.clear_pending_signal()
            return

        # Tick the entry window counter on every candle
        self.tracker.tick_pending_signal()

        # ── Only scan for new patterns if entry is allowed ────
        if not self.session.is_entry_allowed():
            return

        if not self.tracker.can_take_new_trade():
            logger.debug(f"Cannot take new trade | {self.tracker.summary_str()}")
            return

        # ── Pattern detection ─────────────────────────────────
        candles = self._get_completed_candles_from_app()
        if candles is None or len(candles) < 3:
            return

        pattern = scan_for_pattern(candles, entry_buffer=ENTRY_BUFFER_OPTIONS)
        if pattern is None:
            return

        logger.info(f"{'='*60}")
        logger.info(f"PATTERN DETECTED: {pattern}")
        logger.info(f"{'='*60}")

        # ── Determine direction and option type ───────────────
        if pattern.pattern_type == "MORNING_STAR":
            direction   = "BUY"
            option_type = "CE"     # Buy Call for bullish signal
        else:
            direction   = "SELL"
            option_type = "PE"     # Buy Put for bearish signal (buy PE then sell)

        # ── Strike selection ──────────────────────────────────
        spot = self._nifty_spot
        if spot is None:
            logger.warning("Spot price unavailable. Cannot select strike.")
            return

        strike_info = self.strikes.get_option(spot, option_type)
        if strike_info is None:
            logger.error("Strike selection failed. Skipping pattern.")
            return

        # ── Arm pending signal ────────────────────────────────
        pending = PendingSignal(
            pattern_type    = pattern.pattern_type,
            direction       = direction,
            option_type     = option_type,
            entry_trigger   = pattern.entry_trigger,
            sl_index_price  = pattern.pattern_low if direction == "BUY"
                              else pattern.pattern_high,
        )
        self.tracker.set_pending_signal(pending)

        # Store strike info for when trigger fires
        self._pending_strike_info = strike_info
        self._pending_pattern     = pattern

        logger.info(
            f"Signal armed | {direction} {strike_info['display_name']} | "
            f"Trigger={pattern.entry_trigger:.2f} | "
            f"Window=2 candles"
        )

    # ── Entry trigger check (called on every tick) ─────────────

    def _check_entry_trigger_on_tick(self, spot_ltp: float):
        pending = self.tracker.get_pending_signal()
        if pending is None:
            return

        triggered = False
        if pending.direction == "BUY" and spot_ltp >= pending.entry_trigger:
            triggered = True
        elif pending.direction == "SELL" and spot_ltp <= pending.entry_trigger:
            triggered = True

        if not triggered:
            return

        logger.info(
            f"ENTRY TRIGGERED | {pending.direction} | "
            f"Spot={spot_ltp:.2f} >= trigger={pending.entry_trigger:.2f}"
        )

        self.tracker.clear_pending_signal()
        self._execute_entry(spot_ltp)

    def _execute_entry(self, trigger_price: float):
        if not hasattr(self, "_pending_strike_info") or self._pending_strike_info is None:
            logger.error("_execute_entry called but no pending strike info!")
            return

        pattern     = self._pending_pattern
        strike_info = self._pending_strike_info

        pending = self.tracker.get_pending_signal()
        # Re-fetch direction from pattern since pending was cleared
        if pattern.pattern_type == "MORNING_STAR":
            direction = "BUY"
        else:
            direction = "SELL"

        # Calculate SL and TP in options premium space
        # Pattern SL levels are in index points; we use them directly
        # as option premium reference (same magnitude approximation for paper trade)
        sl_price, tp_price = self.orders.calculate_sl_tp(
            direction    = direction,
            entry_price  = trigger_price,
            pattern_high = pattern.pattern_high,
            pattern_low  = pattern.pattern_low,
        )

        trade = self.orders.place_entry_order(
            direction      = direction,
            security_id    = strike_info["security_id"],
            exchange       = strike_info["exchange"],
            entry_trigger  = trigger_price,
            sl_price       = sl_price,
            tp_price       = tp_price,
            strike_info    = strike_info,
        )

        if trade is None:
            logger.error("Entry order failed!")
            return

        self.tracker.open_trade(trade)
        self._pending_strike_info = None
        self._pending_pattern     = None

        print(f"\n{GREEN}{BOLD}{'▶ TRADE ENTERED ':=<55}{RESET}")
        print(f"  {direction} {strike_info['display_name']}")
        print(f"  Entry : {trigger_price:.2f}")
        print(f"  SL    : {sl_price:.2f}")
        print(f"  TP    : {tp_price:.2f}")
        print(f"  Mode  : {'PAPER' if PAPER_TRADE else 'LIVE'}")
        print(f"{'':=<55}")

    # ── SL / TP monitoring ────────────────────────────────────

    def _check_sl_tp_on_tick(self, spot_ltp: float):
        trade = self.tracker.get_active_trade()
        if trade is None or not trade.is_open():
            return

        if trade.direction == "BUY":
            if spot_ltp <= trade.sl_price:
                logger.info(f"STOP LOSS HIT | {spot_ltp:.2f} <= {trade.sl_price:.2f}")
                self._exit_trade(trade, spot_ltp, "SL")
            elif spot_ltp >= trade.tp_price:
                logger.info(f"TAKE PROFIT HIT | {spot_ltp:.2f} >= {trade.tp_price:.2f}")
                self._exit_trade(trade, spot_ltp, "TP")

        elif trade.direction == "SELL":
            if spot_ltp >= trade.sl_price:
                logger.info(f"STOP LOSS HIT | {spot_ltp:.2f} >= {trade.sl_price:.2f}")
                self._exit_trade(trade, spot_ltp, "SL")
            elif spot_ltp <= trade.tp_price:
                logger.info(f"TAKE PROFIT HIT | {spot_ltp:.2f} <= {trade.tp_price:.2f}")
                self._exit_trade(trade, spot_ltp, "TP")

    def _exit_trade(self, trade: ActiveTrade, price: float, reason: str):
        fill = self.orders.place_exit_order(trade, reason, price)
        self.tracker.close_trade(fill, reason)
        pnl = (fill - trade.entry_price) * trade.quantity \
              if trade.direction == "BUY" \
              else (trade.entry_price - fill) * trade.quantity
        col = GREEN if pnl >= 0 else RED
        print(f"\n{col}{BOLD}{'◀ TRADE CLOSED ':=<55}{RESET}")
        print(f"  Reason : {reason}")
        print(f"  Entry  : {trade.entry_price:.2f} | Exit: {fill:.2f}")
        print(f"  PnL    : {col}{pnl:+.2f}{RESET}")
        print(f"{'':=<55}")

    def _force_exit(self, reason: str):
        trade = self.tracker.get_active_trade()
        if trade and trade.is_open():
            spot = self._nifty_spot or trade.entry_price
            self._exit_trade(trade, spot, reason)

    # ── Hook: set completed candles getter from App ───────────

    def set_candle_source(self, fn):
        """fn() should return list of completed candles (oldest→newest)."""
        self._get_completed_candles_from_app = fn

    def _get_completed_candles_from_app(self):
        return []


# ─────────────────────────────────────────────────────────────
# App — WebSocket + threads
# ─────────────────────────────────────────────────────────────

class App:
    def __init__(self):
        self.stop_event = threading.Event()
        self.ws: Optional[websocket.WebSocketApp] = None
        self._lock = threading.Lock()
        self._ws_error: Optional[str] = None

        # NIFTY index candle engine
        self.nifty_engine = CandleEngine(
            sec_id=NIFTY_INDEX_SECURITY_ID,
            name="NIFTY 50",
            history_len=50,
        )

        # Strategy brain
        self.strategy = StrategyEngine()

        # Wire candle close callback
        self.nifty_engine.on_candle_close_cb = self._on_nifty_candle_close

        # Wire candle source to strategy
        self.strategy.set_candle_source(
            lambda: self.nifty_engine.get_completed_candles()
        )

        # Subscribe instruments: [NIFTY index]
        self._instruments = [
            {"exchange": NIFTY_INDEX_EXCHANGE, "security_id": NIFTY_INDEX_SECURITY_ID},
        ]

    def _on_nifty_candle_close(self, sec_id: str, candle: Dict[str, Any]):
        """Fired by CandleEngine whenever a 1m candle closes."""
        ts = datetime.fromtimestamp(candle["bucket"], tz=IST).strftime("%H:%M")
        logger.info(
            f"Candle closed [{ts}] "
            f"O={candle['open']:.2f} H={candle['high']:.2f} "
            f"L={candle['low']:.2f} C={candle['close']:.2f} "
            f"Ticks={candle['tick_count']}"
        )
        self.strategy.on_nifty_candle_close(sec_id, candle)

    # ── WebSocket handlers ────────────────────────────────────

    def on_open(self, ws):
        logger.info("WebSocket connected. Subscribing instruments...")
        sub_msg = {
            "RequestCode":     REQ_SUB_TICKER,
            "InstrumentCount": len(self._instruments),
            "InstrumentList":  [
                {"ExchangeSegment": i["exchange"], "SecurityId": i["security_id"]}
                for i in self._instruments
            ],
        }
        ws.send(json.dumps(sub_msg))

    def on_message(self, ws, message):
        if isinstance(message, str):
            return

        msg = bytes(message)
        hdr = parse_header_8(msg)
        if not hdr:
            return

        code   = int(hdr["resp_code"])
        sec_id = str(hdr["security_id"])

        if code == RESP_TICKER and sec_id == NIFTY_INDEX_SECURITY_ID:
            t = parse_ticker(hdr["payload"])
            if not t:
                return
            ltp = float(t["ltp"])
            ltt = int(t["ltt_epoch"])
            self.nifty_engine.on_tick(ltp, ltt)
            self.strategy.on_nifty_tick(ltp)

    def on_error(self, ws, error):
        with self._lock:
            self._ws_error = str(error)
        logger.error(f"WebSocket error: {error}")

    def on_close(self, ws, status_code, msg):
        logger.warning(f"WebSocket closed: {status_code} {msg}")

    # ── WS loop with auto-reconnect ───────────────────────────

    def run_ws_loop(self):
        websocket.enableTrace(False)
        while not self.stop_event.is_set():
            try:
                self.ws = websocket.WebSocketApp(
                    WS_URL,
                    on_open=self.on_open,
                    on_message=self.on_message,
                    on_error=self.on_error,
                    on_close=self.on_close,
                )
                self.ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception as e:
                logger.error(f"WS exception: {e}")
            finally:
                if not self.stop_event.is_set():
                    logger.info("Reconnecting in 3s...")
                    time.sleep(3)

    # ── Status display loop ───────────────────────────────────

    def run_status_loop(self):
        while not self.stop_event.is_set():
            time.sleep(30)
            try:
                spot = self.nifty_engine.get_ltp()
                spot_str = f"{spot:.2f}" if spot else "N/A"
                session  = self.strategy.session.status_str()
                summary  = self.strategy.tracker.summary_str()
                logger.info(
                    f"STATUS | Spot={spot_str} | Session={session} | {summary}"
                )
            except Exception as e:
                logger.error(f"Status loop error: {e}")

    # ── Start / Stop ──────────────────────────────────────────

    def start(self):
        mode = f"{'PAPER TRADE' if PAPER_TRADE else 'LIVE TRADE'}"
        logger.info(f"{'='*55}")
        logger.info(f"  Morning Star / Evening Star Strategy")
        logger.info(f"  Mode: {mode}")
        logger.info(f"  Instrument: NIFTY Weekly Options (Delta ~0.6)")
        logger.info(f"{'='*55}")

        ws_t      = threading.Thread(target=self.run_ws_loop,    daemon=True)
        status_t  = threading.Thread(target=self.run_status_loop, daemon=True)
        ws_t.start()
        status_t.start()

    def stop(self):
        self.stop_event.set()
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass

        # Print trade log on exit
        log = self.strategy.tracker.get_trade_log()
        if log:
            print(f"\n{BOLD}{'─'*55}{RESET}")
            print(f"{BOLD}  Session Trade Log{RESET}")
            print(f"{'─'*55}")
            for t in log:
                pnl_val = t.get('pnl', None)
                pnl_str = f"{pnl_val:+.2f}" if pnl_val is not None else "OPEN"
                col     = GREEN if (pnl_val or 0) >= 0 else RED
                print(
                    f"  #{t.get('trade_no','-')} | {t.get('type')} | "
                    f"{t.get('option','?')} | "
                    f"Entry={t.get('entry',0):.2f} | "
                    f"{col}PnL={pnl_str}{RESET} | "
                    f"Reason={t.get('exit_reason','?')}"
                )
            total = self.strategy.tracker.total_pnl()
            col   = GREEN if total >= 0 else RED
            print(f"{'─'*55}")
            print(f"  {BOLD}Day PnL: {col}{total:+.2f}{RESET}")
            print(f"{'─'*55}\n")


# ─────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────

def main():
    app = App()

    def _sig_handler(sig, frame):
        print(f"\n{YELLOW}Shutting down...{RESET}")
        app.stop()
        raise SystemExit(0)

    signal.signal(signal.SIGINT,  _sig_handler)
    signal.signal(signal.SIGTERM, _sig_handler)

    app.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        app.stop()


if __name__ == "__main__":
    main()
