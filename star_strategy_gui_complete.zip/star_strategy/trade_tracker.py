# trade_tracker.py
# ─────────────────────────────────────────────────────────────
# Tracks:
#   - Active trade state (one at a time)
#   - Daily trade counter (max 5)
#   - Entry window countdown (pattern valid for N candles)
#   - Realized P&L for the day
#   - Trade log
# ─────────────────────────────────────────────────────────────

import threading
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict, Any

import pytz

from config import MAX_TRADES_PER_DAY, ENTRY_CANDLE_WINDOW

logger = logging.getLogger(__name__)
IST = pytz.timezone("Asia/Kolkata")


@dataclass
class ActiveTrade:
    direction: str              # "BUY" or "SELL"
    option_type: str            # "CE" or "PE"
    security_id: str
    display_name: str
    strike: float
    expiry: str

    entry_price: float          # Options premium at entry
    sl_price: float             # Hard stop loss
    tp_price: float             # Take profit

    quantity: int
    order_id: str               # Dhan order ID (or "PAPER" in paper mode)
    sl_order_id: str
    tp_order_id: str

    entry_time: datetime = field(default_factory=lambda: datetime.now(IST))
    exit_price: Optional[float] = None
    exit_time: Optional[datetime] = None
    exit_reason: Optional[str] = None  # "SL" | "TP" | "TIME_EXIT" | "MANUAL"
    pnl: Optional[float] = None

    def is_open(self) -> bool:
        return self.exit_price is None


@dataclass
class PendingSignal:
    """
    Holds a detected pattern waiting for price to breach entry trigger.
    Valid for ENTRY_CANDLE_WINDOW candles after detection.
    """
    pattern_type: str           # "MORNING_STAR" | "EVENING_STAR"
    direction: str              # "BUY" | "SELL"
    option_type: str            # "CE" | "PE"
    entry_trigger: float        # Price level to breach
    sl_index_price: float       # Index-level SL (pattern high/low)
    candles_remaining: int = ENTRY_CANDLE_WINDOW


class TradeTracker:
    def __init__(self):
        self._lock = threading.Lock()

        self._active_trade: Optional[ActiveTrade] = None
        self._pending_signal: Optional[PendingSignal] = None

        self._daily_trade_count: int = 0
        self._trade_log: List[Dict[str, Any]] = []

        self._session_date: Optional[str] = None   # YYYY-MM-DD
        self._total_pnl: float = 0.0

    def _today_str(self) -> str:
        return datetime.now(IST).strftime("%Y-%m-%d")

    def _check_reset_daily(self):
        today = self._today_str()
        if self._session_date != today:
            self._session_date = today
            self._daily_trade_count = 0
            self._total_pnl = 0.0
            logger.info(f"New session date: {today}. Daily counters reset.")

    # ── Queries ──────────────────────────────────────────────

    def has_active_trade(self) -> bool:
        with self._lock:
            return self._active_trade is not None and self._active_trade.is_open()

    def can_take_new_trade(self) -> bool:
        with self._lock:
            self._check_reset_daily()
            return (
                self._active_trade is None
                and self._daily_trade_count < MAX_TRADES_PER_DAY
                and self._pending_signal is None
            )

    def get_active_trade(self) -> Optional[ActiveTrade]:
        with self._lock:
            return self._active_trade

    def get_pending_signal(self) -> Optional[PendingSignal]:
        with self._lock:
            return self._pending_signal

    def daily_trade_count(self) -> int:
        with self._lock:
            return self._daily_trade_count

    def total_pnl(self) -> float:
        with self._lock:
            return self._total_pnl

    # ── Pending Signal Management ─────────────────────────────

    def set_pending_signal(self, signal: PendingSignal):
        with self._lock:
            self._pending_signal = signal
            logger.info(
                f"Pending signal set: {signal.pattern_type} {signal.direction} "
                f"trigger={signal.entry_trigger:.2f} | "
                f"Window={signal.candles_remaining} candles"
            )

    def tick_pending_signal(self) -> bool:
        """
        Called each time a new candle closes.
        Decrements window counter.
        Returns True if signal is still valid, False if expired.
        """
        with self._lock:
            if self._pending_signal is None:
                return False
            self._pending_signal.candles_remaining -= 1
            if self._pending_signal.candles_remaining <= 0:
                logger.info(
                    f"Pending signal EXPIRED ({self._pending_signal.pattern_type}). "
                    f"Entry window closed."
                )
                self._pending_signal = None
                return False
            return True

    def clear_pending_signal(self):
        with self._lock:
            self._pending_signal = None

    # ── Trade Lifecycle ───────────────────────────────────────

    def open_trade(self, trade: ActiveTrade):
        with self._lock:
            self._check_reset_daily()
            self._active_trade = trade
            self._pending_signal = None
            self._daily_trade_count += 1
            log_entry = {
                "trade_no":   self._daily_trade_count,
                "type":       trade.direction,
                "option":     trade.display_name,
                "entry":      trade.entry_price,
                "sl":         trade.sl_price,
                "tp":         trade.tp_price,
                "qty":        trade.quantity,
                "order_id":   trade.order_id,
                "entry_time": trade.entry_time.strftime("%H:%M:%S"),
            }
            self._trade_log.append(log_entry)
            logger.info(
                f"Trade #{self._daily_trade_count} OPENED | "
                f"{trade.direction} {trade.display_name} @ {trade.entry_price:.2f} | "
                f"SL={trade.sl_price:.2f} TP={trade.tp_price:.2f}"
            )

    def close_trade(self, exit_price: float, exit_reason: str):
        with self._lock:
            if self._active_trade is None:
                return
            t = self._active_trade
            t.exit_price  = exit_price
            t.exit_time   = datetime.now(IST)
            t.exit_reason = exit_reason

            if t.direction == "BUY":
                t.pnl = (exit_price - t.entry_price) * t.quantity
            else:
                t.pnl = (t.entry_price - exit_price) * t.quantity

            self._total_pnl += t.pnl

            # Update trade log
            for log in reversed(self._trade_log):
                if log.get("order_id") == t.order_id:
                    log["exit"]       = exit_price
                    log["exit_reason"]= exit_reason
                    log["pnl"]        = t.pnl
                    log["exit_time"]  = t.exit_time.strftime("%H:%M:%S")
                    break

            logger.info(
                f"Trade CLOSED | {t.direction} {t.display_name} | "
                f"Entry={t.entry_price:.2f} Exit={exit_price:.2f} | "
                f"Reason={exit_reason} | PnL={t.pnl:+.2f}"
            )
            self._active_trade = None

    def get_trade_log(self) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self._trade_log)

    def summary_str(self) -> str:
        with self._lock:
            self._check_reset_daily()
            active = "YES" if (self._active_trade and self._active_trade.is_open()) else "NO"
            pending = "YES" if self._pending_signal else "NO"
            return (
                f"Trades: {self._daily_trade_count}/{MAX_TRADES_PER_DAY} | "
                f"Active: {active} | "
                f"Pending Signal: {pending} | "
                f"Day PnL: {self._total_pnl:+.2f}"
            )
