# pattern_detector.py
# ─────────────────────────────────────────────────────────────
# Morning Star & Evening Star pattern detection
# Operates on a list of completed 1-minute OHLC candles
#
# Body ratio thresholds (industry standard quant definitions):
#   Large body (C1, C3): body / range >= 0.60
#   Small body (C2):     body / range <= 0.35
# ─────────────────────────────────────────────────────────────

from dataclasses import dataclass
from typing import Dict, Any, Optional, List
from config import LARGE_BODY_RATIO, SMALL_BODY_RATIO, MIN_CANDLE_RANGE
import logging

logger = logging.getLogger(__name__)


@dataclass
class PatternResult:
    pattern_type: str           # "MORNING_STAR" or "EVENING_STAR"
    c1: Dict[str, Any]          # Candle 1 OHLC dict
    c2: Dict[str, Any]          # Candle 2 OHLC dict
    c3: Dict[str, Any]          # Candle 3 OHLC dict

    # Key levels for order management
    pattern_high: float         # Highest high of the 3 candles
    pattern_low: float          # Lowest low of the 3 candles
    c3_high: float
    c3_low: float
    c1_midpoint: float          # Midpoint of C1's body

    # Entry trigger prices
    entry_trigger: float        # Price to breach for entry (with buffer applied)

    def __str__(self):
        return (
            f"[{self.pattern_type}] "
            f"C3 H={self.c3_high:.2f} L={self.c3_low:.2f} | "
            f"PatternH={self.pattern_high:.2f} PatternL={self.pattern_low:.2f} | "
            f"EntryTrigger={self.entry_trigger:.2f}"
        )


def _body_ratio(candle: Dict[str, Any]) -> float:
    """body / total range. Returns 0 if range is negligible."""
    rng = float(candle["high"]) - float(candle["low"])
    if rng < MIN_CANDLE_RANGE:
        return 0.0
    body = abs(float(candle["close"]) - float(candle["open"]))
    return body / rng


def _is_bearish(candle: Dict[str, Any]) -> bool:
    return float(candle["close"]) < float(candle["open"])


def _is_bullish(candle: Dict[str, Any]) -> bool:
    return float(candle["close"]) > float(candle["open"])


def _is_large_body(candle: Dict[str, Any]) -> bool:
    return _body_ratio(candle) >= LARGE_BODY_RATIO


def _is_small_body(candle: Dict[str, Any]) -> bool:
    rng = float(candle["high"]) - float(candle["low"])
    if rng < MIN_CANDLE_RANGE:
        return True         # Near-zero range → treat as doji/small
    return _body_ratio(candle) <= SMALL_BODY_RATIO


def _c1_midpoint(c1: Dict[str, Any]) -> float:
    """Midpoint of C1's real body (not H-L range)."""
    o = float(c1["open"])
    c = float(c1["close"])
    return (o + c) / 2.0


def detect_morning_star(
    c1: Dict[str, Any],
    c2: Dict[str, Any],
    c3: Dict[str, Any],
    entry_buffer: float = 1.0,
) -> Optional[PatternResult]:
    """
    Morning Star (Bullish Reversal) — SOP conditions:
      C1: Strong bearish, large body
      C2: Small body (any color), low is lowest of all 3
      C3: Strong bullish, large body, close > midpoint of C1 body
      Pattern confirmation: low of C2 == lowest of 3 candles
    """
    # C1: bearish + large body
    if not (_is_bearish(c1) and _is_large_body(c1)):
        return None

    # C2: small body
    if not _is_small_body(c2):
        return None

    # C3: bullish + large body
    if not (_is_bullish(c3) and _is_large_body(c3)):
        return None

    # C2 low must be LOWER than both C1 low and C3 low (SOP rule 6)
    c2_low  = float(c2["low"])
    c1_low  = float(c1["low"])
    c3_low  = float(c3["low"])
    if not (c2_low < c1_low and c2_low < c3_low):
        return None

    # C3 close must be ABOVE midpoint of C1 body (SOP rule 10)
    mid = _c1_midpoint(c1)
    if float(c3["close"]) <= mid:
        return None

    # Pattern confirmation: C2.low == pattern low (already guaranteed above)
    pattern_low  = min(c1_low, c2_low, c3_low)
    pattern_high = max(float(c1["high"]), float(c2["high"]), float(c3["high"]))

    # Entry trigger: break above C3 high + buffer
    entry_trigger = float(c3["high"]) + entry_buffer

    logger.info(f"MORNING_STAR detected | C3_high={c3['high']:.2f} trigger={entry_trigger:.2f}")

    return PatternResult(
        pattern_type   = "MORNING_STAR",
        c1=c1, c2=c2, c3=c3,
        pattern_high   = pattern_high,
        pattern_low    = pattern_low,
        c3_high        = float(c3["high"]),
        c3_low         = float(c3["low"]),
        c1_midpoint    = mid,
        entry_trigger  = entry_trigger,
    )


def detect_evening_star(
    c1: Dict[str, Any],
    c2: Dict[str, Any],
    c3: Dict[str, Any],
    entry_buffer: float = 1.0,
) -> Optional[PatternResult]:
    """
    Evening Star (Bearish Reversal) — SOP conditions:
      C1: Strong bullish, large body
      C2: Small body (any color), high is highest of all 3
      C3: Strong bearish, large body, close < midpoint of C1 body
      Pattern confirmation: high of C2 == highest of 3 candles
    """
    # C1: bullish + large body
    if not (_is_bullish(c1) and _is_large_body(c1)):
        return None

    # C2: small body
    if not _is_small_body(c2):
        return None

    # C3: bearish + large body
    if not (_is_bearish(c3) and _is_large_body(c3)):
        return None

    # C2 high must be HIGHER than both C1 high and C3 high (SOP rule 6)
    c2_high = float(c2["high"])
    c1_high = float(c1["high"])
    c3_high = float(c3["high"])
    if not (c2_high > c1_high and c2_high > c3_high):
        return None

    # C3 close must be BELOW midpoint of C1 body (SOP rule 10)
    mid = _c1_midpoint(c1)
    if float(c3["close"]) >= mid:
        return None

    # Pattern confirmation: C2.high == pattern high (already guaranteed above)
    pattern_high = max(c1_high, c2_high, c3_high)
    pattern_low  = min(float(c1["low"]), float(c2["low"]), float(c3["low"]))

    # Entry trigger: break below C3 low - buffer
    entry_trigger = float(c3["low"]) - entry_buffer

    logger.info(f"EVENING_STAR detected | C3_low={c3['low']:.2f} trigger={entry_trigger:.2f}")

    return PatternResult(
        pattern_type   = "EVENING_STAR",
        c1=c1, c2=c2, c3=c3,
        pattern_high   = pattern_high,
        pattern_low    = pattern_low,
        c3_high        = float(c3["high"]),
        c3_low         = float(c3["low"]),
        c1_midpoint    = mid,
        entry_trigger  = entry_trigger,
    )


def scan_for_pattern(
    candles: List[Dict[str, Any]],
    entry_buffer: float = 1.0,
) -> Optional[PatternResult]:
    """
    Scan the last 3 completed candles for either pattern.
    `candles` should be ordered oldest → newest.
    Returns the first (most recent) pattern found, or None.
    """
    if len(candles) < 3:
        return None

    c1, c2, c3 = candles[-3], candles[-2], candles[-1]

    result = detect_morning_star(c1, c2, c3, entry_buffer)
    if result:
        return result

    result = detect_evening_star(c1, c2, c3, entry_buffer)
    return result
