# order_manager.py
# ─────────────────────────────────────────────────────────────
# Handles all order operations via dhanhq SDK
# Currently in PAPER TRADE mode: logs all orders, no real execution
#
# Paper trade uses Dhan's official paper trading API endpoint
# which is the same SDK call with paper credentials or
# simulated locally — orders are logged and tracked internally.
# ─────────────────────────────────────────────────────────────

import logging
import uuid
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple

from dhanhq import dhanhq

from config import (
    DHAN_CLIENT_ID, DHAN_ACCESS_TOKEN,
    PAPER_TRADE, QUANTITY, RISK_REWARD_RATIO,
    MAX_SL_INDEX_POINTS,
)
from trade_tracker import ActiveTrade

logger = logging.getLogger(__name__)


def _make_paper_order_id(prefix: str = "PAPER") -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8].upper()}"


class OrderManager:
    def __init__(self):
        self._dhan = dhanhq(DHAN_CLIENT_ID, DHAN_ACCESS_TOKEN)
        mode = "PAPER TRADE" if PAPER_TRADE else "LIVE"
        logger.info(f"OrderManager initialized | Mode: {mode}")

    # ── SL / TP Calculation ───────────────────────────────────

    def calculate_sl_tp(
        self,
        direction: str,
        entry_price: float,
        pattern_high: float,
        pattern_low: float,
    ) -> Tuple[float, float]:
        """
        BUY:  SL = pattern_low  | TP = entry + 1.5 * risk
        SELL: SL = pattern_high | TP = entry - 1.5 * risk
        Returns (sl_price, tp_price) in OPTIONS PREMIUM points.
        """
        if direction == "BUY":
            risk    = entry_price - pattern_low
            sl      = pattern_low
            tp      = entry_price + (RISK_REWARD_RATIO * risk)
        else:
            risk    = pattern_high - entry_price
            sl      = pattern_high
            tp      = entry_price - (RISK_REWARD_RATIO * risk)

        # Sanity: risk must be positive
        if risk <= 0:
            logger.warning(f"Invalid risk={risk:.2f} for {direction}. Using 5pt fallback.")
            risk = 5.0
            sl   = (entry_price - 5.0) if direction == "BUY" else (entry_price + 5.0)
            tp   = (entry_price + RISK_REWARD_RATIO * 5.0) if direction == "BUY" \
                   else (entry_price - RISK_REWARD_RATIO * 5.0)

        logger.info(
            f"SL/TP | Dir={direction} Entry={entry_price:.2f} "
            f"Risk={risk:.2f} SL={sl:.2f} TP={tp:.2f}"
        )
        return round(sl, 2), round(tp, 2)

    # ── Entry Order ───────────────────────────────────────────

    def place_entry_order(
        self,
        direction: str,
        security_id: str,
        exchange: str,
        entry_trigger: float,
        sl_price: float,
        tp_price: float,
        strike_info: Dict[str, Any],
    ) -> Optional[ActiveTrade]:
        """
        Places entry as a LIMIT order at entry_trigger price.
        In paper trade mode: simulates order at trigger price.
        Returns ActiveTrade if successful, None on failure.
        """
        transaction_type = dhanhq.BUY if direction == "BUY" else dhanhq.SELL
        order_type       = dhanhq.LIMIT
        product_type     = dhanhq.INTRA         # Intraday

        if PAPER_TRADE:
            # ── Paper Trade ──────────────────────────────────
            order_id    = _make_paper_order_id("ENTRY")
            sl_order_id = _make_paper_order_id("SL")
            tp_order_id = _make_paper_order_id("TP")

            # Simulate fill at entry trigger price
            fill_price = entry_trigger

            logger.info(
                f"[PAPER] ENTRY ORDER | {direction} {strike_info['display_name']} "
                f"@ {fill_price:.2f} | SL={sl_price:.2f} TP={tp_price:.2f} "
                f"Qty={QUANTITY} | OrderID={order_id}"
            )

            trade = ActiveTrade(
                direction    = direction,
                option_type  = strike_info["option_type"],
                security_id  = security_id,
                display_name = strike_info["display_name"],
                strike       = strike_info["strike"],
                expiry       = strike_info["expiry"],
                entry_price  = fill_price,
                sl_price     = sl_price,
                tp_price     = tp_price,
                quantity     = QUANTITY,
                order_id     = order_id,
                sl_order_id  = sl_order_id,
                tp_order_id  = tp_order_id,
            )
            return trade

        else:
            # ── Live Trade (future use) ───────────────────────
            try:
                resp = self._dhan.place_order(
                    security_id   = security_id,
                    exchange_segment = exchange,
                    transaction_type = transaction_type,
                    quantity      = QUANTITY,
                    order_type    = order_type,
                    product_type  = product_type,
                    price         = entry_trigger,
                )
                if resp.get("status") != "success":
                    logger.error(f"Entry order failed: {resp}")
                    return None

                order_id = str(resp.get("data", {}).get("orderId", ""))

                # Place SL order
                sl_resp = self._place_sl_order(
                    direction, security_id, exchange, sl_price, product_type
                )
                tp_resp = self._place_tp_order(
                    direction, security_id, exchange, tp_price, product_type
                )

                trade = ActiveTrade(
                    direction    = direction,
                    option_type  = strike_info["option_type"],
                    security_id  = security_id,
                    display_name = strike_info["display_name"],
                    strike       = strike_info["strike"],
                    expiry       = strike_info["expiry"],
                    entry_price  = entry_trigger,
                    sl_price     = sl_price,
                    tp_price     = tp_price,
                    quantity     = QUANTITY,
                    order_id     = order_id,
                    sl_order_id  = str(sl_resp.get("data", {}).get("orderId", "")),
                    tp_order_id  = str(tp_resp.get("data", {}).get("orderId", "")),
                )
                return trade

            except Exception as e:
                logger.error(f"Exception placing live entry order: {e}")
                return None

    def _place_sl_order(self, direction, security_id, exchange, sl_price, product_type):
        """Stop-loss order (opposite direction)."""
        t_type = dhanhq.SELL if direction == "BUY" else dhanhq.BUY
        return self._dhan.place_order(
            security_id      = security_id,
            exchange_segment = exchange,
            transaction_type = t_type,
            quantity         = QUANTITY,
            order_type       = dhanhq.SL,
            product_type     = product_type,
            price            = sl_price,
            trigger_price    = sl_price,
        )

    def _place_tp_order(self, direction, security_id, exchange, tp_price, product_type):
        """Take-profit limit order (opposite direction)."""
        t_type = dhanhq.SELL if direction == "BUY" else dhanhq.BUY
        return self._dhan.place_order(
            security_id      = security_id,
            exchange_segment = exchange,
            transaction_type = t_type,
            quantity         = QUANTITY,
            order_type       = dhanhq.LIMIT,
            product_type     = product_type,
            price            = tp_price,
        )

    # ── Exit / Cancel ─────────────────────────────────────────

    def cancel_order(self, order_id: str):
        if PAPER_TRADE:
            logger.info(f"[PAPER] CANCEL order {order_id}")
            return

        try:
            resp = self._dhan.cancel_order(order_id)
            logger.info(f"Cancel order {order_id}: {resp}")
        except Exception as e:
            logger.error(f"Cancel order {order_id} failed: {e}")

    def place_exit_order(
        self,
        trade: ActiveTrade,
        exit_reason: str,
        exit_price: Optional[float] = None,
    ) -> float:
        """
        Exits the active trade at market (or given price for paper).
        Returns the fill price used.
        """
        if PAPER_TRADE:
            fill = exit_price if exit_price is not None else trade.sl_price
            logger.info(
                f"[PAPER] EXIT | {trade.direction} {trade.display_name} "
                f"@ {fill:.2f} | Reason={exit_reason}"
            )
            return fill

        # Live: place market order to close position
        t_type = dhanhq.SELL if trade.direction == "BUY" else dhanhq.BUY
        try:
            resp = self._dhan.place_order(
                security_id      = trade.security_id,
                exchange_segment = trade.exchange if hasattr(trade, "exchange") else "NSE_FNO",
                transaction_type = t_type,
                quantity         = trade.quantity,
                order_type       = dhanhq.MARKET,
                product_type     = dhanhq.INTRA,
                price            = 0,
            )
            fill = float(resp.get("data", {}).get("price", exit_price or 0))
            logger.info(f"Live EXIT placed: {resp}")
            return fill
        except Exception as e:
            logger.error(f"Live exit order failed: {e}")
            return exit_price or 0.0
