# strike_selector.py
# ─────────────────────────────────────────────────────────────
# Selects the NIFTY options strike closest to Delta 0.6
#
# Dhan doesn't provide live greeks via WebSocket.
# We approximate Delta ~0.6 by:
#   1. Find ATM strike (nearest to current NIFTY spot)
#   2. Delta 0.6 ≈ 1st–2nd strike IN-THE-MONEY from ATM
#      (For CALL: 1-2 strikes below ATM
#       For PUT:  1-2 strikes above ATM)
#   3. From Dhan scrip master CSV, pick the nearest weekly expiry
#      option at that strike
#
# On expiry day → switch to next week's contract automatically
# ─────────────────────────────────────────────────────────────

import logging
from datetime import datetime, date
from io import StringIO
from typing import Optional, Dict, Any

import pandas as pd
import requests
import pytz

from config import (
    INSTRUMENT_CSV_URL, OPTIONS_UNDERLYING,
    OPTIONS_EXCHANGE, OPTIONS_INSTRUMENT,
)

logger = logging.getLogger(__name__)
IST = pytz.timezone("Asia/Kolkata")

# NIFTY strikes are in multiples of 50
NIFTY_STRIKE_STEP = 50

# How many strikes ITM from ATM ≈ delta 0.6
# Delta 0.6 ≈ 1 strike ITM (conservative) to 2 strikes ITM
DELTA_06_STRIKES_ITM = 1  # tunable: 1 or 2


class StrikeSelector:
    def __init__(self):
        self._df: Optional[pd.DataFrame] = None
        self._loaded_date: Optional[date] = None

    def _load_scrip_master(self) -> pd.DataFrame:
        today = datetime.now(IST).date()
        if self._df is not None and self._loaded_date == today:
            return self._df

        logger.info("Fetching Dhan scrip master for options strike resolution...")
        r = requests.get(INSTRUMENT_CSV_URL, timeout=30)
        r.raise_for_status()

        usecols = [
            "EXCH_ID", "SEGMENT", "SECURITY_ID", "INSTRUMENT",
            "SYMBOL_NAME", "DISPLAY_NAME", "SM_EXPIRY_DATE",
            "SM_STRIKE_PRICE", "SM_OPTION_TYPE",
        ]
        df = pd.read_csv(StringIO(r.text), usecols=usecols, low_memory=False)

        for c in ["EXCH_ID", "SEGMENT", "INSTRUMENT", "SYMBOL_NAME",
                  "DISPLAY_NAME", "SM_OPTION_TYPE"]:
            df[c] = df[c].astype(str).str.strip().str.upper()

        df["SM_EXPIRY_DATE"]   = pd.to_datetime(df["SM_EXPIRY_DATE"], errors="coerce")
        df["SM_STRIKE_PRICE"]  = pd.to_numeric(df["SM_STRIKE_PRICE"], errors="coerce")
        df["SECURITY_ID"]      = df["SECURITY_ID"].astype(str).str.strip()

        # Filter to NIFTY weekly options only
        mask = (
            (df["SYMBOL_NAME"]  == OPTIONS_UNDERLYING.upper()) &
            (df["INSTRUMENT"]   == OPTIONS_INSTRUMENT.upper()) &
            (df["SEGMENT"]      == "NSE_FNO") &
            df["SM_EXPIRY_DATE"].notna() &
            df["SM_STRIKE_PRICE"].notna()
        )
        self._df = df[mask].copy()
        self._loaded_date = today
        logger.info(f"Loaded {len(self._df)} NIFTY option rows from scrip master")
        return self._df

    def _get_target_expiry(self, df: pd.DataFrame) -> Optional[pd.Timestamp]:
        """
        Return the nearest weekly expiry.
        If today IS the expiry day → use next week's expiry (SOP rule).
        """
        today = pd.Timestamp(datetime.now(IST).date())
        future_expiries = (
            df["SM_EXPIRY_DATE"]
            .dropna()
            .unique()
        )
        future_expiries = sorted([e for e in future_expiries if e >= today])

        if not future_expiries:
            logger.error("No future expiries found in scrip master!")
            return None

        nearest = future_expiries[0]

        # If nearest expiry == today, use next week (SOP: expiry day → next contract)
        if nearest.date() == today.date() and len(future_expiries) > 1:
            logger.info(f"Today is expiry day ({nearest.date()}). Switching to next week.")
            return future_expiries[1]

        logger.info(f"Target expiry: {nearest.date()}")
        return nearest

    def _atm_strike(self, spot: float) -> float:
        """Round spot to nearest NIFTY_STRIKE_STEP."""
        return round(spot / NIFTY_STRIKE_STEP) * NIFTY_STRIKE_STEP

    def get_option(
        self,
        spot: float,
        option_type: str,           # "CE" or "PE"
    ) -> Optional[Dict[str, Any]]:
        """
        Returns dict with security_id, strike, expiry, display_name
        for the Delta-0.6 equivalent strike.

        Delta ~0.6:
          CE: DELTA_06_STRIKES_ITM strikes BELOW ATM (i.e. ITM call)
          PE: DELTA_06_STRIKES_ITM strikes ABOVE ATM (i.e. ITM put)
        """
        try:
            df = self._load_scrip_master()
        except Exception as e:
            logger.error(f"Scrip master load failed: {e}")
            return None

        expiry = self._get_target_expiry(df)
        if expiry is None:
            return None

        atm = self._atm_strike(spot)
        ot  = option_type.upper()

        if ot == "CE":
            target_strike = atm - (DELTA_06_STRIKES_ITM * NIFTY_STRIKE_STEP)
        elif ot == "PE":
            target_strike = atm + (DELTA_06_STRIKES_ITM * NIFTY_STRIKE_STEP)
        else:
            logger.error(f"Unknown option_type: {option_type}")
            return None

        sub = df[
            (df["SM_EXPIRY_DATE"]  == expiry) &
            (df["SM_OPTION_TYPE"]  == ot) &
            (df["SM_STRIKE_PRICE"] == target_strike)
        ]

        if sub.empty:
            # Fallback: nearest available strike to target
            sub_exp = df[
                (df["SM_EXPIRY_DATE"] == expiry) &
                (df["SM_OPTION_TYPE"] == ot)
            ].copy()
            if sub_exp.empty:
                logger.error(f"No options found for expiry {expiry.date()} {ot}")
                return None
            sub_exp["dist"] = (sub_exp["SM_STRIKE_PRICE"] - target_strike).abs()
            sub = sub_exp.nsmallest(1, "dist")

        row = sub.iloc[0]
        result = {
            "security_id":  str(row["SECURITY_ID"]),
            "exchange":     OPTIONS_EXCHANGE,
            "strike":       float(row["SM_STRIKE_PRICE"]),
            "expiry":       str(expiry.date()),
            "option_type":  ot,
            "display_name": str(row["DISPLAY_NAME"]),
        }
        logger.info(
            f"Strike selected: {result['display_name']} | "
            f"secId={result['security_id']} | "
            f"Strike={result['strike']} | Expiry={result['expiry']}"
        )
        return result
