# session_guard.py
# ─────────────────────────────────────────────────────────────
# IST time-based gate logic for the strategy session
# ─────────────────────────────────────────────────────────────

from datetime import datetime, time as dtime
import pytz

IST = pytz.timezone("Asia/Kolkata")


def _now_ist() -> datetime:
    return datetime.now(IST)


def _parse_hhmm(t: str) -> dtime:
    h, m = t.split(":")
    return dtime(int(h), int(m))


class SessionGuard:
    """
    Encapsulates all time-based rules.

    Rules (from SOP):
      09:29 → session opens, entries allowed
      14:45 → last entry allowed
      15:10 → cancel all pending orders
      15:15 → force exit all open positions
    """

    def __init__(
        self,
        session_start: str = "09:29",
        last_entry: str    = "14:45",
        cancel_pending: str = "15:10",
        force_exit: str    = "15:15",
    ):
        self.t_session_start  = _parse_hhmm(session_start)
        self.t_last_entry     = _parse_hhmm(last_entry)
        self.t_cancel_pending = _parse_hhmm(cancel_pending)
        self.t_force_exit     = _parse_hhmm(force_exit)

    def _now_time(self) -> dtime:
        return _now_ist().time().replace(second=0, microsecond=0)

    def is_entry_allowed(self) -> bool:
        """True between 09:29 and 14:45 (inclusive)."""
        t = self._now_time()
        return self.t_session_start <= t <= self.t_last_entry

    def is_cancel_pending_time(self) -> bool:
        """True from 15:10 onwards."""
        return self._now_time() >= self.t_cancel_pending

    def is_force_exit_time(self) -> bool:
        """True from 15:15 onwards."""
        return self._now_time() >= self.t_force_exit

    def is_market_hours(self) -> bool:
        """True from 09:15 to 15:30 (broad market hours)."""
        t = self._now_time()
        return dtime(9, 15) <= t <= dtime(15, 30)

    def status_str(self) -> str:
        t = self._now_time()
        if t < self.t_session_start:
            return "PRE-SESSION"
        elif t <= self.t_last_entry:
            return "TRADING"
        elif t < self.t_cancel_pending:
            return "NO-NEW-ENTRY"
        elif t < self.t_force_exit:
            return "CANCELLING"
        else:
            return "FORCE-EXIT"
